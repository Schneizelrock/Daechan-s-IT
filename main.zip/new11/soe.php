<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>

  <section id="main">
    <div class="container">
      <article id="main-sexy">
        <h1 class="page-title">School of Engineering</h1>
        <h2>Overview</h2>
        <p>The school of engineering at Presidency University envisages to transform young inquisitive minds into engineers of tomorrow having strong fundamental knowledge, excellent skills, the right attitude and active members of the community.

   The B.Tech. programme is a FOUR-year course (academic years). Each academic year has TWO semesters during which courses are offered as per the structure. Some courses may be offered during the summer term too. The first year builds a strong foundation with basic courses in humanities, sciences, mathematics and engineering sciences. Core courses specific to the discipline are offered from the second year onwards. Electives are offered from the THIRD year onwards, helping the students choose the courses of their choice.</p>
<h2>Industrial Practice[IP]</h2>
  <p>The curriculum through IP finds a formal method of bringing the reality of the professional world into the educational process. It is a part of the total programme and takes the classroom for a period of 7 ½ months to a professional location where students get involved in finding solutions to real-life problems of the industry. The programme requires the students to undergo the rigour of the professional world in form as well as in substance, providing them an opportunity to apply their classroom knowledge to live issues in the industry.
  The IP programme has two components, namely Industrial Practice – I (IP-I) and Industrial Practice – II (IP-II). For the undergraduate B.Tech programme, IP-I is conducted for a duration of eight weeks during the summer following the second year second semester, and IP – II, having a duration of five and a half months, is implemented during either of the semesters of the final year. For undergraduate B.Tech students, Industrial Practice has a total weightage of 25 credits.</p>

      </article>


      <aside id="sidebar">
        <div class="dark">
          <h3>Offered Courses</h3>
          <li><a style="color:white" href="computer.php">Computer Science</a></li>
          <li><a style="color:white" href="petroleum.php">Petroleum Engineering</a></li>
          <li><a style="color:white" href="mechanical.php">Mechanical Engineering</a></li>
          <li><a style="color:white" href="eee.php">Electrical and Electronics Engineering</a></li>
          <li><a style="color:white" href="ece.php">Electronics and Communications Engineering</a></li>
          <li><a style="color:white" href="civil.php">Civil engineering</a></li>
        </div>
        </aside>
    </div>
  </section>

</div>



           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>Operations and Supply Chain Management</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>Operations and Supply Chain Management aspects have always been vital to organizations. This management area, which federates organisational facets as diverse as Procurement, Material Handling, Transportation, Warehousing, Inventory Management, Production, Sales, and Customer Service, represents a synthesis of practices , methods and techniques coming from traditional business areas of Accounting & Finance, Management, and Marketing, as well as business decision-making tools offered by Operations Research, Statistics, and Managerial Economics. This Program and its courses together examine logistics systems that facilitate the physical supply of raw and intermediate materials to an organisation, the planning and control of operations, and the delivery of the products or services to the final customers, aimed at achieving a sustainable competitive advantage and optimizing the value and the long-term performance of the organisation and the supply chain as a whole.</p>
<br>
<h2>KEY FEATURES</h2>
<p>Dynamic Industry-Integrated Course Structure and Curriculum
Contemporary, Relevant and Progressive Pedagogy and Curriculum Compatible with Global Requirements.
Reinforced Teaching-Learning Practices emphasizing – Experiential approach to Knowledge Transfer, Case Study and Brain Storming Sessions on Academic subjects.
Focused Co- Curricular Development through Seminar Series, Guest Lectures from Eminent Personalities, Skill Enhancement Programs [SEP] and Soft Skill Development.
Extra curricular activities like Industrial visits, Literary Club, Social Outreach, Management Club and Newsletter Editorial.
A Finishing School Approach to Overall Development of the Student.</p>
<h2>INDUSTRIAL PRACTICE [IP]</h2>
<p>Monitored Internship of 2 months, post First Year, Reinforced with a 4-months Stipendiary industrial
Envisages Guest Lectures on emerging Aspects of Business and industry.
Under the aegis of the Industry-Interface Program, Management Development Programs, Executive Development Programs,Panel discussions driven by industry doyens and the academic stalwarts will be conducted to make students Industry-Worthy.
Industrial Practice is a Pre Placement Exercise aimed at providing the students with a hands-on experience, making them industry ready.</p>




</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

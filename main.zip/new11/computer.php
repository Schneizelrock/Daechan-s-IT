<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>COMPUTER SCIENCE ENGINEERING</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>Welcome to the Computer Science & Engineering Department in the School of Engineering, Presidency University, Bengaluru.<br><br>

We work with the motivation and dedication to impart the best knowledge to highly talented students admitted in our department. A wide range of courses are offered to students to help them understand the various intricacies involved in computing. The courses are designed in a way to invoke students’ ability to think originally and creatively. The faculty members of the CS department are trained to produce computer engineers with the ability to design and develop systems involving the integration of software and hardware devices. The department is equipped with modern computer labs, with well-trained lab assistants, to empower students with a better understanding of the theory lecture sessions and to give them an exposure to practical problem solving.</p>
<br>
<h2>CAREER OPPORTUNITIES</h2>
<p>Computer science engineers have job opportunities in the software industry and almost all the other sectors too. There are three main domains in the job market for computer science engineers, viz application, system and support. Some of the common designations are Software Developers, Web Developers, Database Administrators, Computer/ System Programmers, Computer Hardware Engineers, Network and Computer Systems Administrators etc.</p>

  <br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>





</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

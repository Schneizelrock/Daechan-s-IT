<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>ELECTRONICS AND COMMUNICATION ENGINEERING</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>Welcome to the Electronics and Communication Engineering Department in the School of Engineering, Presidency University, Bengaluru.<br><br>

The department is dedicated to the teaching and research activities in the areas of Electronics and Communication Engineering. The department educates students to take up challenging jobs in a wide range of industries and engage themselves in research and development activities for the good of society.<br><br>

Courses offered by the department cater to learning needs from the basics to the advanced level. The department offers a variety of discipline electives and covers most of the modern technologies. The state-of-the-art laboratories provide hands-on experiences and support research activities.</p>
<br>
<h2>CAREER OPPORTUNITIES</h2>
<p>Graduate Electronics and Communication Engineers enter into careers in state/central government jobs, telecommunication industry, military and manufacturing industry. Some common portfolios are telecommunications engineer, design engineer, signals and systems engineer.</p>

  <br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>





</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

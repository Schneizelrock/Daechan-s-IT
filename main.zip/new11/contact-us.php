<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>




   <section id="main">
     <div class="container">
       <article id="main-sexy">

<section id="boxes" >
<div class="container" width="80%">
<div class="box">

<h3>Admission Enquiry</h3>
<p>9538812343 || 9538712341 || 9538712342</p>
</div>
<div class="box">

<h3>Board line number</h3>
<p>080-23093500</p>
</div>
<div class="box">

<h3>Admission Office</h3>
<address><strong>Presidency University</strong><br>
#83,Venkatadri Complex,<br>
Richmond Road<br>
Bengaluru-560025, Karnataka, India<br>
Tel: 080 4925 5533 / Mob : +91 92431 17175 </address>
<a href="mailto:Daechan@presidency.in">Daechan@presidency.in</a>
</div>
<div class="box">

<h3>Campus</h3>
<p><address>Presidency University<br>
Itgalpur, Rajanakunte,<br>
Yelahanka, Bengaluru 560064<br>
(10 kms from Yelahanka Town)</address></p>
</div>

<div class="box">

<h3>Location</h3>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d7432650.745763091!2d79.8241674941642!3d14.344807125694807!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sen!2sin!4v1520451422082" width="500" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
</div>
</section>




       </article>

     </div>
 </section>
 <br>
 <br>
           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

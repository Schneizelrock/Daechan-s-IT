<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>APi</title>
  </head>
  <body>
    <iframe src="https://calendar.google.com/calendar/embed?showPrint=0&amp;showTabs=0&amp;height=600&amp;wkst=1&amp;hl=en&amp;bgcolor=%23cccccc&amp;src=rakeshshaw114%40gmail.com&amp;color=%231B887A&amp;src=pvlltvmoild33tp48cn4kld0t0%40group.calendar.google.com&amp;color=%238C500B&amp;src=%23contacts%40group.v.calendar.google.com&amp;color=%236B3304&amp;ctz=Asia%2FCalcutta" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>

  </body>
</html>

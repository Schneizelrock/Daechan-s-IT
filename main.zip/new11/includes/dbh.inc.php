<<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "1234";
$dbName = "loginsystem";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

<?php
session_start();
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
              
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>




   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title">About Us</h1>
         <p>Presidency Group of Institutions (PGI), along with the University, constitutes 7 Schools and a College. While the college offers programmes to students at both the undergraduate and postgraduate levels in information technology, commerce, management and journalism, the schools offer National and International boards of studies. Presidency College, located in Bengaluru, has been accredited with an ‘A’ grade by NAAC. The postgraduate MBA programme at Presidency College is approved by the AICTE, Delhi. Within a short span of three decades, PGI has created a niche for itself as one of the top-notch institutions in Bengaluru. Recently, Presidency Group of Institutions (PGI) was bestowed with the “Most Promising Institute in South India” award at the British South India Council of Commerce and Business Meet 2014.

         The latest venture of the group Presidency University is a testimony to the fact that the group has almost over three decades of experience in education from K to 12 to Higher Education. Presidency University aspires to be among the best universities in the world in the shortest span possible, with focus on innovative and research oriented teaching methodology, state-of-the-art facilities, industry-friendly curriculum with concrete action plans and an unwavering commitment to the pursuit of excellence.</p>
<p class="dark">
  Presidency University’s vision is to be a world-class University. We believe in nurturing talent amongst all those who enter our portals. Through this close nurturing of talent and skills in each individual, we aim to transform students to become successful professionals and responsible citizens. We accomplish all these through excellence in teaching, best in pedagogy borrowed from the world, an efficient research and study cell, service and community development in focus. Our commitment is towards shaping lives of students through scholarly exposure, pedagogy and learning and that which contributes to making the youth future ready for the world at large..</p>
       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>Presiedncy-Logo</h3>
         <p>Just as a bird nestles itself in its nest until its young ones are fashioned for flight, so does Presidency afford sustenance to all those aspirants who enter the portals of the University with food for thought, action, scholarly pursuit intermixed with ethics and moral values. Like the flight of the birds, students go out into the world soaring to greater heights of accomplishments in life.</p>
       </div>
       </aside>
     </div>
 </section>
 <br>
 <br>
           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>Civil Engineering</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>Welcome to the Civil Engineering Department in the School of Engineering, Presidency University, Bengaluru.<br><br>

The department offers the first degree programme with the modular structure and various flexibilities, which include options such as Electives, Industrial Practice components, etc. The curriculum provides a broad-based foundation to the Undergraduates. Students gain experience by enhancing their conceptual knowledge and skills of engineering design, planning, execution and management through varied specialised course work in structures, construction materials, water resources, transportation and utility lifeline systems, environmental engineering and infrastructure management under the guidance of experienced faculty.<br><br>

Civil Engineering graduates are highly sought after by design firms, engineering consultants, materials manufacturers, and government agencies, in addition to contracting and construction companies. Graduates will have an option to work as project engineers, structural designers, transportation planners, technical sales engineers, engineers at construction site, design researchers and so on. The field remains very popular with a number of industries, not only in construction, but also with government agencies such as roads and transport authorities, electricity and water authorities, and real estate development authorities.</p>
<br>
<h2>CAREER OPPORTUNITIES</h2>
<p>Graduate civil engineers can flourish in careers in the areas of irrigation, infrastructural development, structural design, planning, design and construction of bridges, tunnels, highways, airports, railways, water works, sanitation system. They can also have opportunities for jobs in government departments, such as roads and building, PWD, panchayat raj, irrigation, rural water supply, town planning, pollution control boards, remote sensing and GIS-based organisations, etc. Equal opportunities are available in quantity estimation and surveying, environmental impact and pollution control studies. Some common designations are design engineer, project engineer, site engineer, etc.</p>






<br>
<br>
<br>
<br>
<br>
<br>
<br>





</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

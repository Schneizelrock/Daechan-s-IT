<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>BBA.LLB (HONS)</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>The Integrated 5-year Bachelor Degree Program in Law has transformed the quality of legal education. It was conceived with an objective to bring legal education as a complete professional course and provide the opportunity for a fresh 10+2 pass-out student to make an immediate career choice.

The interdependence between social sciences and law hardly needs to be articulated.  With the rapid growth of the Indian economy and global business footprint, integration of management sciences, economics and commerce with legal education becomes a necessity to ensure qualified and skilled graduates to cater to diverse opportunities in the legal profession.

The School of Law has specifically designed  three different Integrated Bachelor DegreeHonors Programs, viz., B.A.,LL.B.[Hons.], BBA.,LL.B.{Hons.], and B.Com.,LL.B.[Hons.], to prepare legal professionals for the diverse contexts.</p>
<br>
<h2>LEGAL PEDAGOGY AT PRESIDENCY UNIVERSITY</h2>
<p>The pedagogy adopted for such Integrated Programs emphasizes multi-disciplinary research and inquiry, participative learning, blended learning using online resources, case studies and discussion seminars in addition to the classroom lectures.  A very critical aspect of the learning process is to develop the skills and attitudes imperative for competence as a legal professional. With this objective the Integrated Honors Law Curriculum has courses on personal and professional skill development like Professional Communication (including courses in general and legal English), Researching and Reasoning Skills, Advocacy Skills and Drafting Skills. All such skills are refined through Moot Courts, Legal Aid Clinics and Internships that are conducted in compliance with the requirements of the Bar Council of India.</p>
<br>
<h2>CAREER PROSPECTS AND OPTIONS</h2>
<p>A law graduate is faced with a variety of career options. Judicial Services is well known and the traditional career path. A flourishing legal industry is growing in lockstep with India’s economic growth creating extraordinary opportunities for lawyers and law firms. National and Multinational Corporations offer diverse career opportunities in legal services and departments, covering areas like International Trade and Commerce, Intellectual Property Rights, Global Mobility and International Laws. The emergence of LPO (Legal Process Outsourcing)opens up career opportunities in several specialized legal services, particularly in Legal Research.</p>
<br>


</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>




   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title" style="font-size:32px">Alumni Tours </h1>
         <h2 class="page-title" style="font-size:22px">Why should Gustavus students have all the fun and all the learning? The Gustavus community embraces alumni, parents, and other friends to join the journey.</h2>
         <p><strong>Friends of Music:</strong> Many people have fond memories of their student days going on tour with a musical ensemble. Now is the chance to experience the growth through culture and music, without the home stays and pot-luck dinners. Friends of Music offers companion trips with Gustavus student performing ensembles and stand-alone trips.</p>
         <p><strong>Study Tours:</strong> It is time to become a student again and experience the world without the tests and papers. Gustavus faculty experts know the destination highlights found in any guide book and then take travelers deeper. The faculty are experienced guides designing trips that are a mix of learning and leisure, sharing their vast knowledge and passion for a destination and utilizing their connections to discover unique experiences.</P>
         <h1 style="font-size:32px">Upcoming Study Tours </h1>

         <p style="font-size:20px"><strong>ULC-Service Tour</strong>
          <p>Led by <strong>De.James Mathew and Vinitha Dominic</strong> on March 27,2018.



       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>Award Nomination</h3>
         <p>Nominations for the 2018 Alumni Association Awards are due by april 15, 2018. </p>
       </div>
       </aside>
     </div>
 </section>
 <br>
 <br>
           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

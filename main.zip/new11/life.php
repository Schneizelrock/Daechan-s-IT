<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <h1>Life at Hendrix</h1>
          <p>Hendrix student life means club meetings, music and theatre, games and guest speakers, sports and student government. And that's just one week.</p>

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FPresidencyUniversityBangalore%2Fvideos%2F1372156429557295%2F&show_text=0&width=560" width="1060" height="615" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
        <section id="boxes">
 <div class="container">
   <div class="box">
     <img src="./img/life1.png">
     <h3>Schedule A Visit</h3>
     <p>Visit our campus and see what presidency has to offer.</p>
   </div>
   <div class="box">
     <img src="./img/life2.png">
     <h3>New Learning Commons</h3>
     <p>Students can now access peer tutoring services more easily, thanks to the new learning commons.</p>
   </div>
   <div class="box">
     <img src="./img/life.png">
     <h3>Students Marathon</h3>
     <p>Once a year, Marathon-time.The event is organised by University and listed as one of the major events in Presidency.</p>


   </div>
   <h2>Student Activities</h2>
   <p>Presidency students stay active long after lectures and labs are over for the day. Student activities keep students' calendars full with events and programs for the whole community.</p>

   <section id="boxes">
<div class="container">
<div class="box">
<img src="./img/life3.png">
<h3>New Student Orientation</h3>
<p>New student orientation gets first-year students ready for life at presidency.</p>
</div>
<div class="box">
<img src="./img/life4.png">
<h3>Clubs and Organization</h3>
<p>More that 40 clubs and organizations keep students connected to classmates who share interests.</p>
</div>
<div class="box">
<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FPresidencyUniversityBangalore%2Fvideos%2F1352968418142763%2F&show_text=0&width=560" width="400" height="270" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
<h3>Campus Tradition</h3>
<p>When you talk about Presidency, it's like you're speaking another language.</p>


</div>
 </div>
</section>




</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li  class="current"><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">
            <section id="showcase">
              <div class="container">
               <h1>Once a Presidian, Always a Presidian.</h1>
              </div>
            </section>
<h1><center>Admission</center></h1>
<p style="width:80%">Can you spend all day (and more) talking about big ideas and asking questions? Are you excited when you discover the answer to something you never knew before? Do you like to raise your hand in class … whether or not you know the answer? If this sounds like you, think about Hendrix.</p>

            <section id="boxes">
   <div class="container">
     <div class="box">
       <img src="./img/.png">
       <h3>Admission Counselors</h3>
       <p>Our admission team has one role and one goal: To be your advocate during your college search and to help you decide if Presidency is the right fit. They know Presidency. They know our students — and they want to get to know you.</p>
     </div>
     <div class="box">
       <img src="./img/.png">
       <h3>Admission Requirements</h3>
       <p>Here's what we recommend and required for admission at Presidency, whether you're a high school student, home-schooled student, transfer or non-degree-seeking student.</p>
     </div>
<h3>Check-onto the system</h3>
<li><a style="color:Red" href="adsoe.php">School of Engineering</a></li>
<li><a style="color:Red" href="adsom.php">School of Management</a></li>
<li><a style="color:Red" href="adsol.php">School of Law</a></li>

   </div>
 </section>


</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>
<br>

          <footer>
    <p>Presidency-Alumni, Copyright &copy; 2018</p>
  </footer>
  </body>
</html>

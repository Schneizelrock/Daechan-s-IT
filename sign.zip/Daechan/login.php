<?php
session_start();
 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Login Here</title>
     <link rel="stylesheet" type="text/css" href="stylelogin.css">
   </head>
   <body>

     <?php
           if (isset($_SESSION['u_id'])) {
             echo '<form action="includes/logout.inc.php"
             method="POST">
             <button type="submit" name="submit">Logout</button>
             </form>';
           } else {
             echo '<form class="signup-form" action="includes/login.inc.php" method="POST">
               <input type="text" name="uid" placeholder="Username/e-mail" required>
               <input type="password" name="pwd" placeholder="Password" required>
               <button type="submit" name="submit">Login</button>
             </form>';

           }
      ?>


   </body>
 </html>

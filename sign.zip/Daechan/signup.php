<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Sign-Up</title>
    <link rel="stylesheet" type="text/css" href="stylelogin.css">
  </head>
  <body>



<?php
if (isset($_SESSION['u_id'])) {
  echo "You are logged in!";
}
 ?>


    <h2><center>Signup</center></h2>
    <form class="signup-form" action="includes/signup.inc.php" method="POST">
      <input type="text" name="first" placeholder="Firstname" required>
      <input type="text" name="last" placeholder="Lastname" required>
      <input type="text" name="email" placeholder="E-mail" required>
      <input type="text" name="uid" placeholder="Username" required>
      <input type="password" name="pwd" placeholder="Password" required>
      <button type="submit" name="submit">Sign up</button>
    </form>
<a style="color:red" href="login.php"><center>login</center></a>

<?php
      if (isset($_SESSION['u_id'])) {
        echo '<form action="includes/logout.inc.php"
        method="POST">
        <button type="submit" name="submit">Logout</button>
        </form>';
      } else {
        echo '<form class="signup-form" action="includes/login.inc.php" method="POST">
          <input type="text" name="uid" placeholder="Username/e-mail" required>
          <input type="password" name="pwd" placeholder="Password" required>
          <button type="submit" name="submit">Login</button>
        </form>';

      }
 ?>
  </body>
</html>

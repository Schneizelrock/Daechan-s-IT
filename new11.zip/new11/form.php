<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Sign-Up | Current Student</title>
    <link rel="stylesheet" type="text/css" href="stylelogin.css">
  </head>
  <body>

      <form class="signup-form" method="POST" action="123.php">
      <input type="text" name="first" placeholder="FirstName....">
        <input type="text" name="last" placeholder="LastName....."><br>
        Year of Study<select name="Year of Study">
          <option value="2015-2019">2015-2019</option>
          <option value="2016-2020">2016-2020</option>
          <option value="2017-2021">2017-2021</option>
          <option value="2018-2022">2018-2022</option>
        </select><br>
        Branch<select name="Branch">
          <option value="2015-2019">2015-2019</option>
          <option value="2016-2020">2016-2020</option>
          <option value="2017-2021">2017-2021</option>
          <option value="2018-2022">2018-2022</option>
        </select><br>
        <input type="text" name="ID-no." placeholder="ID-no.....">

      </form>

  </body>
</html>

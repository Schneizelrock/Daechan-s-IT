<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>Petroleum Engineering</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>Welcome to the Petroleum Engineering Department in the School of Engineering, Presidency University, Bengaluru.<br><br>

The Petroleum Engineering Department in Presidency University is dedicated to the teaching and research in both upstream and downstream areas of Petroleum Engineering. The department offers the first degree programme with the modular structure and various flexibilities, including Electives, Industrial Practice components etc. The curriculum provides broad-based foundation to the Undergraduates. Students enhance their conceptual knowledge and skills of engineering in exploration, drilling, reservoir, production, surface operations and management courses under the guidance of experienced faculty. The students have a scope of learning various courses which are useful in research and thereby can pursue higher education as well as have a probability in joining Research and Development (R & D) sectors of the industry.</p>

<br>
<h2>CAREER OPPORTUNITIES</h2>
<p>Graduate petroleum engineers enter into careers in state/central government jobs and oil/gas extraction industry. It is an emerging engineering field. The private oil and gas industry also offers excellent opportunities. Engineers are required in the petroleum industry in oil and gas extraction, support activities for mining, management of companies and enterprises, petroleum and coal products manufacturing and engineering services. Some common designations are completions engineer, drilling engineer, production engineer, reservoir engineer</p>
  <br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>





</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

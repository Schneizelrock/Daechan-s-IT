
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>




    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li class="current"><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
              <li><a href="index.php">comments</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>

            <section id="showcase">
              <div class="container">
              <h1><i>ALUMNI<i></h1>
               <h1>Once a Presidian, Always a Presidian.</h1>
              </div>
            </section>

            <section id="boxes">
   <div class="container">
     <div class="box">
       <img src="./img/3.png">
       <h3>Be Challenged.</h3>
       <p>A liberal education isn’t easy. You don’t just “learn a little about a lot.” You read, think, write, argue, change your mind, and shape your unique view of the world. You constantly discover. It happens in lectures and labs, in recital halls and residence halls. It happens on the playing field and in field research. It doesn’t stop. That’s Presidency.</p>
     </div>
     <div class="box">
       <img src="./img/1.png">
       <h3>Be Engaged.</h3>
       <p>Here, you don’t just take notes and take tests. You learn to take chances and to make the whole world your classroom.That’s engaged learning at Presidency.</p>
     </div>
     <div class="box">
       <img src="./img/2.png">
       <h3>Be Ready.</h3>
       <p>We’re here to help you transition from a student to a leader on campus and beyond.We help you prepare for graduate or professional school, the workforce and the world. That’s a liberal degree from Presidency.</p>
     </div>
   </div>
 </section>

 <section id="boxes">
<div class="container">
<div class="box">
<img src="./img/4.png">
<h3>Be Active.</h3>
<p>Our campus doesn’t close when class is dismissed. Presidency students fill their days with everything from arts and athletics to special events and speakers.</p>
</div>
<div class="box">
<img src="./img/5.png">
<h3>Be At Home.</h3>
<p>Welcome to a place that celebrates uniqueness. At Presidency, you won’t find fraternities and sororities, reserved parking for the President or outsourced dining service.</p>
</div>
<div class="box">
<img src="./img/6.png">
<h3>Be Awesome.</h3>
<p>Our alumni are proof that you can do anything with a liberal arts degree from Hendrix.</p>
</div>
</div>
</section>

</div>

<div class="event" align="right">
  <h1>Check Out the Events</h1>
  <iframe src="https://calendar.google.com/calendar/embed?showPrint=0&amp;showTabs=0&amp;height=600&amp;wkst=1&amp;hl=en&amp;bgcolor=%23cccccc&amp;src=rakeshshaw114%40gmail.com&amp;color=%231B887A&amp;src=pvlltvmoild33tp48cn4kld0t0%40group.calendar.google.com&amp;color=%238C500B&amp;src=%23contacts%40group.v.calendar.google.com&amp;color=%236B3304&amp;ctz=Asia%2FCalcutta" style="border-width:0" width="400" height="300" frameborder="0" scrolling="no"></iframe>
</div>
</div>
          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>
<br>

          <footer>
    <p>Presidency-Alumni, Copyright &copy; 2018</p>
  </footer>
  </body>
</html>

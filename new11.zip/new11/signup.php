
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="stylelogin.css">

  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li class="current"><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>




<?php
if (isset($_SESSION['u_id'])) {
  echo "You are logged in!";
}
 ?>


    <h2><center>Signup</center></h2>
    <form class="signup-form" action="includes/signup.inc.php" method="POST">
      <input type="text" name="first" placeholder="Firstname" required>
      <input type="text" name="last" placeholder="Lastname" required>
      <input type="text" name="email" placeholder="E-mail" required>
      <input type="text" name="uid" placeholder="Username" required>
      <input type="password" name="pwd" placeholder="Password" required>
      <button type="submit" name="submit">Sign up</button>
    </form>
<a style="color:red" href="login.php"><center>login</center></a>



          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>
<br>

          <footer>
    <p>Presidency-Alumni, Copyright &copy; 2018</p>
  </footer>
  </body>
</html>

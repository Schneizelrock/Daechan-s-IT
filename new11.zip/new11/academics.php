
<?php
session_start();
 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li class="current"><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">
            <section id="showcase">
              <div class="container">
               <h1>Once a Presidian, Always a Presidian.</h1>
              </div>
            </section>

            <h1><center>Overview</center></h1>
            <p>The school of engineering at Presidency University envisages to transform young inquisitive minds into engineers of tomorrow having strong fundamental knowledge, excellent skills, the right attitude and active members of the community.

The B.Tech. programme is a FOUR-year course (academic years). Each academic year has TWO semesters during which courses are offered as per the structure. Some courses may be offered during the summer term too. The first year builds a strong foundation with basic courses in humanities, sciences, mathematics and engineering sciences. Core courses specific to the discipline are offered from the second year onwards. Electives are offered from the THIRD year onwards, helping the students choose the courses of their choice.</p>

            <section id="boxes">
   <div class="container">
     <div class="box">
       <img src="./img/soe.png">
       <h3><a style="color:green" href="soe.php">School of Engineering</a></h3>
       <p>The school of engineering at Presidency University envisages to transform young inquisitive minds into engineers of tomorrow having strong fundamental knowledge, excellent skills, the right attitude and active members of the community.</p>
     </div>
     <div class="box">
       <img src="./img/som.png">
       <h3><a style="color:green" href="som.php">School of Management</a></h3>
       <p>The objective of the School of management is to prepare students for the future. It is a challenge that we take on to equip the students today with the right knowledge, skills and attitude that will help them to be effective in any venture they choose. </p>
     </div>
     <div class="box">
       <img src="./img/sol.png">
       <h3><a style="color:green" href="sol.php">School of Law</a></h3>
       <p>The Integrated 5-year Bachelor Degree Program in Law has transformed the quality of legal education. It was conceived with an objective to bring legal education as a complete professional course and provide the opportunity for a fresh 10+2 pass-out student to make an immediate career choice.</p>
     </div>
   </div>
 </section>



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>
<br>

          <footer>
    <p>Presidency-Alumni, Copyright &copy; 2018</p>
  </footer>
  </body>
</html>

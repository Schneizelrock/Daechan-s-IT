<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
            <h1>School of Engineering</h1>
<h1>ELIGIBILITY</h1>
<li>Pre-University / Higher Secondary /10+2 examination Pass with Physics and Mathematics as compulsory subjects along with either Chemistry / Biotechnology / Biology / Technical Vocational subject.</li><br>

<li>Obtained at least 45% marks (40% in case of candidates belonging to Reserved Category) in the above subjects taken together.</li><br>

<li>Appeared for JEE (Main); JEE (Advanced); Karnataka CET; COMED-K; PUEET-2018 or any other State-level Engineering Entrance Examination</li><br>
<br>
<h2>SELECTION CRITERIA</h2>
<li>Candidates are required to appear for the Presidency University Bangalore evaluation test in addition to standard eligibility criteria.</li><br>

<li>Candidates are also required to appear for Personal Interview process.</li><br>

<li>Admissions team also uses scholastic and extra-curricular records.</li><br>

<h2>ADMISSION PROCESS</h2>
<li>Application may be submitted online OR</li>
<li>Application may be downloaded, filled & submitted in person/post OR</li>
<li>Application form can be obtained from the Office of Admissions on payment of 1000/- (One Thousand<br />
     Rupees only) in cash or through Demand Draft drawn in favour of “ Presidency University” payable at Bengaluru</li>
<li>Applicants are requested to submit their filled in Application Form along with attested copies of the below
mentioned documents:</li>
<li>Standard X Mark Sheet</li>
<li>Standard XII Mark Sheet</li>
<li>Transfer Certificate</li>
<li> Migration Certificate (For Non-Karnataka students)</li>
<li>Entrance Exam score card</li>
<li> Passport Size Photographs (5 in No’s)</li>






</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

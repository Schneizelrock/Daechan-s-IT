<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>




   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title" style="font-size:32px">Homecoming</h1>
         <h2 class="page-title" style="font-size:22px">The Great Gustie Gathering <br />November 23, 2021</h2>

         <img src="">
         <p>The Great Presidency Gathering, otherwise known as Homecoming, happens every fall to celebrate everything good about Presidency. Return to Home to relive the Hill with your family, fellow alumni, current students, and the greater Presidency-Alumni community.<br><br>

        Registration includes an all-inclusive pass for breakfast and lunch, access to affinity-based events and activities for all ages throughout the day, and a Presidency swag item. Children under the age of 18 eat and celebrate with us for free!</p>

         <h1 style="font-size:32px">Contact-Us</h1>

         <h2>Admission Office</h2>
         <address>Presidency University<br>
#83,Venkatadri Complex,<br>
Richmond Road<br>
Bengaluru-560025, Karnataka, India<br>
Tel: 080 4925 5533 / Mob : +91 92431 17175 </address>
<a href="mailto:Daechan@presidency.in">Daechan@presidency.in</a>



       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>Award Nomination</h3>
         <p>Nominations for the 2018 Alumni Association Awards are due by april 15, 2018. </p>
       </div>
       </aside>
     </div>
 </section>
 <br>
 <br>
           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

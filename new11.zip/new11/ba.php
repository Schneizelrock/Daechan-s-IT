<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123" style="width:80%">
          <h1>B.A. LL.B (HONS.)</h1>
<h1>PROGRAME OVERVIEW</h1>
<p>The Integrated five-year B.A.,LL.B.[Hons.] Bachelor Degree Honors Program provides a good foundation and insight into political factors influencing policies culminating into law and the intricate relationship between legislations and social problems.This Program aims at creating socially sensitive sentinels of justice. The Program integrates courses in Political Science, Sociology and Economics with the courses in Law for students who prefer to build their careers as Lawyers, Judges and Advocates in the State and Central Judicial Institutions of the country.</p>
<br>
<h2>INTERNSHIPS</h2>
<p>Internships are mandatory according to the BCI norms. To get into a Corporate Law Firm, a student needs guided internship experience. Internships are to be planned and pursued keeping in mind the skills which can be sharpened for a high-paying job with the focussed guidance provided by the experienced faculty. This way, students are exposed to experiential learning and skill-enhancement techniques.</p>
<br>
<h2>CLINICAL COURSES</h2>
<p>Clinical Courses are an important segment of the curriculum where students learn by ‘doing’. BCI-mandated Clinical Courses are further split and allocated into different semesters with greater focus on content. The thrust is on skills associated with Moot Court, Mediation, Trial, Drafting, etc.</p>
<br>
<h2>LEGAL AID CLINIC</h2>
<p>Legal Aid Clinic [LAC] at PUSoL is an important facet in the life and learning of law students. The LAC offers the students an opportunity to interact with the general public and provide deserving members of the community legal guidance to their problems. Students become responsible citizens and feel empowered as lawyers which, in turn, will drive him/her towards the passionate learning of Law. Generating awareness among the community regarding various laws and sensitising the society towards better compliance of laws is also a key objective of LAC.</p>

</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>





           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

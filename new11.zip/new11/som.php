<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>

  <section id="main">
    <div class="container">
      <article id="main-sexy">
        <h1 class="page-title">School of Management</h1>
        <h2>Overview</h2>
        <p>The objective of the School of management is to prepare students for the future. It is a challenge that we take on to equip the students today with the right knowledge, skills and attitude that will help them to be effective in any venture they choose. We believe in nurturing and developing them to become good individuals who are sensitive to the society around them. Learning and teaching in the management school covers all aspect of management. All the specializations are taught and facilitated by very experienced faculty and pedagogy followed is very innovative.

In its vision the Department of Management Studies clearly defines the need to create quality managers and entrepreneurs required to face the challenges of the corporate sector and the growing opportunities for young leaders. The department offers undergraduate courses in Masters Programme in Management (MBA). The modules offered under these courses are challenging and specifically designed to develop and enhance career opportunities and to contribute in the dissemination of academic and applied knowledge in business management.</p>
<h2>Industrial Practice[IP]</h2>
  <p>Monitored Internship of 2 months, post First Year, Reinforced with a  4-months Stipendiary industrial
Envisages Guest Lectures on emerging Aspects of Business and industry.
Under the aegis of the Industry-Interface Program, Management Development Programs, Executive Development Programs   , Panel discussions driven by industry doyens and the academic stalwarts will be conducted to make students Industry-Worthy.
Industrial Practice is a Pre Placement Exercise aimed at providing the students with a hands-on experience, making them industry ready.</p>

      </article>


      <aside id="sidebar">
        <div class="dark">
          <h3>Offered Courses</h3>
          <li><a style="color:white" href="business.php">Business Analytics</a></li>
          <li><a style="color:white" href="finance.php">Finance</a></li>
          <li><a style="color:white" href="marketing.php">Marketing</a></li>
          <li><a style="color:white" href="human.php">Human Resource Management</a></li>
          <li><a style="color:white" href="operation.php">Operations and supply Chain management</a></li>
        </div>
        </aside>
    </div>
  </section>

</div>



           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>




   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title" style="font-size:32px">Presidency Reunion Weekend<br>June 8-10, 2020</h1>
         <h1 class="page-title" style="font-size:27px">We can't wait to welcome you back, Gusties!</h1>
         <p>Beginning in 2017, we will welcome back ALL reunion classes (5-year increments) celebrating an anniversary of their graduation. Reunion Weekend is a chance relive your college days, reminisce with friends, reconnect with the campus, and remember those classmates who have passed.<br><br>

The Alumni and Parent Engagement Office at Gustavus is pleased to offer a hybrid programming model for reunions, complete with opportunities to celebrate together with Gusties from other reunion classes, partake in optional events coordinated by the College, and spend time with your classmates at activities planned by your reunion committee. While there are plenty of elements that will be added in the coming months, you can be sure that the schedule will include:<br><br></p>
         <h1 style="font-size:32px">Future Predicting Testimonials for Reunion Weekend 2020 Attendees</h1>
         <li>"When you come away from a class reunion at Gustavus wishing the weekend didn't have to end, you know it was a successful event. We had all wondered how it would work to have ALL reunion classes on campus at the same time; we needn't have worried. Gustavus came through with flying colors! We're already looking forward to the next reunion in five years!"</li><br>
         <li>"I initially wasn't convinced/didn't really know what to expect of Reunion Weekend given the change of format, but after attending I see so much potential for reunions to be WAY better than they have been in the past."</li><br>
         <li>"The high rating of the reunion experience was a result of the camaraderie of students past and present, the ease in transportation around campus, the wonderful food, the well planned activities, and the sense of connection with Gustavus which is still very much alive and well!"</li><br>
         <li>"The variety allowed me to customize my experience. The size of the attendance allowed me to connect with who I wanted to - for as long as I wanted to. The pace of the events kept things moving so that there was not down time or uncomfortable, lengthy situations. Electing to attend some or all events and topics made it fit into my normal life. Most importantly, the people who were there were approachable, welcoming and not smothering. You could be who you wanted to be, do what you wished to do and experience in a relaxing manner with no expectations."</li><br>
         <li>"I had the time of my life being with my dear friends, but also connecting with other classmates that I rarely if ever spoke to while at school. It was a very friendly, exciting weekend. Truly a Gustie welcome!"</li><br>
         <li>"I was definitely on board with the new format and activities but I was afraid my classmates would not be but they LOVED it all, so my expectations were exceeded!!"</li><br>
         <li>"All meals included; engagement with profs, staff, current students, and other alumni classes; numerous events on & off campus; FELT LIKE HOME AGAIN!"</li><br>


</div>

       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>Award Nomination</h3>
         <p>Nominations for the 2018 Alumni Association Awards are due by april 15, 2018. </p>
       </div>
       </aside>
     </div>
 </section>
 <br>
 <br>
           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

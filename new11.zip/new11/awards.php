<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Presidency-Alumni | Welcome</title>
    <link rel="stylesheet" href="sty.css">
  <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <nav class="navbar">
      <span class="open-slide">
        <a href="#" onclick="openSlideMenu()">
          <svg width="30" height="30">
            <path d="M0,5 30,5" stroke="#000"
            stroke-width="5"/>
            <path d="M0,14 30,14" stroke="#000"
            stroke-width="5"/>
            <path d="M0,23 30,23" stroke="#000"
            stroke-width="5"/>
          </svg>
        </a>
      </span>

      <ul class="navbar-nav">
        <li><a href="s2.php">Home</a></li>
          <li><a href="life.php">Life at Presidency</a></li>
            <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="visit.php">Visit Us</a></li>
              <li  class="current"><a href="about.php">About us</a></li>
              <li><a href="Become-a-member.php">Become A Member</a></li>
              <li><a href="login.php">Login</a></li>
            </ul>
          </nav>

        <div id="side-menu" class="side-nav">

            <a href="#" class="btn-close" onclick="closeSlideMenu()">&times;</a>
            <a href="awards.php">Alumni Awards</a>
            <a href="reunion.php">Presidency Reunion Weekend</a>
            <a href="tours.php">Presidency Tours</a>
            <a href="homecoming.php">Homecoming</a>
            <a href="contact-us.php">Contact Us</a>
          </div>
          <div id="main123">



</div>

          <script>
          function openSlideMenu(){
            document.getElementById('side-menu').style.width='250px';
            document.getElementById('main').style.marginLeft='250px';
          }
          function closeSlideMenu(){
            document.getElementById('side-menu').style.width='0';
            document.getElementById('main').style.marginLeft='0';
          }
          </script>




   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title" style="font-size:32px">Alumni Awards</h1>
         <p>The Presidency Alumni Association has established the following awards to honor alumni and friends of the College who have notably advanced and aided the College; for alumni who have demonstrated exceptional career achievement and brought honor to the College; and to recognize alumni and former students who have made distinctive commitments and contributions to the service of others.</p>
         <h1 style="font-size:32px">Greater Presidian Award</h1>
         <p>The Greater Presidian Award is the highest award given by the Presidians Alumni Association. It is awarded to those "who by deed, have notably advanced and aided Presidency University." </p>
 <h1 style="font-size:32px">Honorary Presidene</h1>
 <p>Established in 2017, the Honorary Presidene recognition pays special tribute to individuals who, while not having graduated from or attended Presidency, have earned the conferred right to be considered bona fide “Presidene” due to their dedicated service to, interest in, and enthusiastic support for the University.</p>

<div class="dark">
         <h1>The Service Award</h1>

  <p>The Service Award of the Presidency University Associations of Congregations recognizes alumni and former students of Presidency University "who have made distinctive commitments and contributions to the service of others."The University and the Associations celebrate the efforts of members of the University community who participate in service activities through volunteer work and extraordinary professional accomplishments. Alumni and former students serve others through their concern for human dignity, moral values, social justice, the care of the earth, the alleviating of poverty, and a range of other social issues.</p>
</div>

       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>Award Nomination</h3>
         <p>Nominations for the 2018 Alumni Association Awards are due by april 15, 2018. </p>
       </div>
       </aside>
     </div>
 </section>
 <br>
 <br>
           <footer>
     <p>Presidency-Alumni, Copyright &copy; 2018</p>
   </footer>
   </body>
 </html>

<?php

namespace pkbpawan\paytm;

use Composer\Composer;
use Composer\IO\IOInterface;
use Composer\Plugin\PluginInterface;

/**
 * Description of PaytmInstallerPlugin
 *
 * @author Pawan Kumar
 */
class PaytmInstallerPlugin implements PluginInterface
{
    public function activate(Composer $composer, IOInterface $io)
    {
    }
}
<?php 
error_reporting(1);
$con = mysqli_connect("localhost","root","1234","hostel");

?>
<center><b>Admission 2014-15</b><br><br>

admission open from 15th july<br><br>

<b>PG cources-:</b><br><br>
Branches:<br>

Computer Science Engineering (120 seats)<br>
Electronics & Communications Engineering(120 seats)<br>
Information & Technology (60 seats)<br>
Electricak Engineering(60 seats)<br>
Civil Engineering(60 seats)<br>
Mechanical Engineerinh(60 seats)<br>
B.Pharma<br><br>

<b>UG cources-:</b><br><br>

Master of Bussiness Management(MBA)<br>
Master of Computer Applications<br>
M.TECH(CSE,ECE,CE,ME,IT,EE)</center>
<div align="center">
<table width="685" height="307" border="1">
  <tbody>
    <tr>
      <td width="345" height="259" style="background-color:#B3B7FF"><center>
        <img src="images/College inner view.jpg" width="277" height="251" alt=""/>
      </center></td>
      <td width="324" style="background-color:#B3B7FF"><center><img src="images/DSC02584.JPG" width="273" height="250" alt=""/></center></td>
    </tr>
    <tr>
      <td height="40" style="background-color:#4F4F4F"><center><font size="+3"><b style="color:#FFFFFF">View Outside Hostel</b></font></center></td>
      <td style="background-color:#4F4F4F"><center><font size="+3"><b style="color:#FFFFFF">View Inside Hostel</b></font></center></td>
    </tr>
  </tbody>
</table>
<table width="685" height="307" border="1">
  <tbody>
    <tr>
      <td width="345" height="259" style="background-color:#B3B7FF"><center>
        <img src="images/MCCID_College_Sports_Area.jpg" width="318" height="238" alt=""/>
      </center></td>
      <td width="324" style="background-color:#B3B7FF"><center>
        <img src="images/sports4.jpg" width="308" height="262" alt=""/>
      </center></td>
    </tr>
    <tr>
      <td height="40" style="background-color:#4F4F4F"><center><font size="+3"><b style="color:#FFFFFF">Basketball Court</b></font></center></td>
      <td style="background-color:#4F4F4F"><center><font size="+3"><b style="color:#FFFFFF">Sports Activities</b></font></center></td>
    </tr>
  </tbody>
</table>
</div>


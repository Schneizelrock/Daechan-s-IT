
<center><b>Notice Board:</b><br><br>

college reopens on 2nd august<br><br>

Sections will be Announced Later...<br><br>

</center>
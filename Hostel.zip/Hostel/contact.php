<h1 style="color:#000000"><b><center>Contact Details</center></b></h1>
<div align="center">
<p><b>Address :</b>Presidency University <br /> Itgalpur, Raajankunte, <br />Yelahanka,<br />Bangalore. India-560064
<p><b>Phone :</b> 080-23093500<br>
<b>Mobile :</b> +91 7353379990
</p>
<p><b>Email :</b> presidencyuniversity@gmail.com</p>
</p>
</div>
<center><b>Weekend events:<b><br><br>

Debate competiton(E/H)<br>

Football inter college competiton<br>

TechByte Quizz competition<br></center>
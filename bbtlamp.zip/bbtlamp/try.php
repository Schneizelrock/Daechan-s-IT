<?php

define('USER_LEVEL',0);
define('ADMIN_LEVEL',1);
define('MOD_LEVEL',2);

$level = USER_LEVEL; // default value

// query for the user's level
$result = mysql_query("SELECT `level` FROM users WHERE id='$userfinal'") or die(mysql_error());
if(mysql_num_rows($result)){
	// matched a row
	list($level) = mysql_fetch_array($result);
}

// you would test the value in $level to determine what to produce on the page.
if($level == ADMIN_LEVEL){
	// produce content for an admin
}

// if you want to produce an $admin variable that is true if the $level == 1 -
$admin = $level == ADMIN_LEVEL ? true : false;

if($admin){
	// produce content for an admin
}

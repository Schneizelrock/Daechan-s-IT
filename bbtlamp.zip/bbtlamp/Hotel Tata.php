<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>



  <body>

   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li class="current"><a href="#">Home</a></li>
           <li><a href="about.html">About us</a></li>
           <li><a href="we.html">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>

   <section id="boxes1">
     <div class="container3">

     <div class="box">
     <h1> Kolkata </h1>
    
     <div class="box">
      <h2> Hotel Tata </h2>

     <img src="./img/5s4.png">
      
     <p>Price : 2100rs
     <form action="payment1.html" method="post">
       <button type="submit" class="button_1">Book Now</button>
        </form></p>
     </div>
     
     
   
     
     </div>
   </section>



   <footer>
     <p>Hotick, copyright &copy; 2017</p>
   </footer>
  </body>
</html>
